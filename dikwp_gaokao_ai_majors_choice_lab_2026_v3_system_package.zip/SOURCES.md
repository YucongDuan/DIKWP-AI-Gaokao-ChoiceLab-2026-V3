# Sources

- Ministry of Education, Notice publishing the Undergraduate Major Catalogue 2026.
- Ministry of Education / 阳光高考, 2026 volunteer-filling guidance and admission charter services.
- State Council, Opinion on implementing the AI+ action, 2025.
- Ministry of Education, national list of higher education institutions as of 2026-06-17.
- Provincial examination authority documents must be used for province-specific final decisions.

All URLs are cited in the companion runbook and presentation.
