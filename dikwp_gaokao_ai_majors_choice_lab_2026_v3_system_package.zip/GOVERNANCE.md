# Governance Boundary

- Do not enter admission account passwords, SMS codes, ID numbers, phone numbers, or full admission ticket numbers.
- Use only official provincial admission plans and university charters for real decisions.
- Treat rank bands as risk categories, not admission probabilities.
- The student must have final preference rights; parents and teachers provide risk control.
- No auto-submission, no admission guarantee, no commercial ranking dependency.
- New AI-related majors require extra verification of承办学院,课程,实验平台,培养方案,校区,学费,分流 and转专业 rules.
