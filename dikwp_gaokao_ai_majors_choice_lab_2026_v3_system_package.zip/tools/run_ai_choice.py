#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json
from pathlib import Path

def read_programs(p: Path):
    with p.open(encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))

def subject_ok(req, subjects):
    return all(x in subjects for x in req.split('+') if x)

def band(rank, rank2025):
    if not rank2025: return '数据不足'
    margin = rank2025 - rank
    if margin < -9000: return '高冲刺'
    if margin < 0: return '冲刺'
    if margin < 8000: return '目标'
    if margin < 20000: return '稳妥'
    return '保底'

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('student', type=Path)
    ap.add_argument('programs_csv', type=Path)
    ap.add_argument('--out', type=Path, default=Path('outputs'))
    args=ap.parse_args()
    stu=json.loads(args.student.read_text(encoding='utf-8'))
    rows=[]
    for r in read_programs(args.programs_csv):
        try: rank2025=int(float(r.get('rank_2025') or 0))
        except Exception: rank2025=0
        ok=subject_ok(r.get('subject_req',''), stu['subjects'])
        rows.append({**r, 'hard_ok': ok, 'band': band(int(stu['rank']), rank2025), 'margin': rank2025-int(stu['rank']) if rank2025 else None})
    rows=[r for r in rows if r['hard_ok']]
    order={'高冲刺':0,'冲刺':1,'目标':2,'稳妥':3,'保底':4,'数据不足':5}
    rows.sort(key=lambda x:(order.get(x['band'],9), -(x['margin'] or -999999)))
    passport={'version':'DIKWP AI Gaokao ChoiceLab 2026 V3 CLI','student':stu,'top_candidates':rows[:30],'warning':'Replace demo data with official 2026 provincial plans and charters.'}
    args.out.mkdir(parents=True,exist_ok=True)
    out=args.out/'ai_gaokao_choice_passport.json'
    out.write_text(json.dumps(passport,ensure_ascii=False,indent=2),encoding='utf-8')
    print(out)
if __name__=='__main__': main()
