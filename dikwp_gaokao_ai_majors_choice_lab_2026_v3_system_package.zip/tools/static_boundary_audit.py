#!/usr/bin/env python3
from pathlib import Path
import re,json
ROOT=Path(__file__).resolve().parents[1]
PAT=[(r'fetch\(','network fetch'),(r'XMLHttpRequest','network xhr'),(r'localStorage','browser storage'),(r'eval\(','dynamic eval'),(r'exec\(','dynamic exec')]
find=[]
for p in ROOT.rglob('*'):
    if not p.is_file() or p.name=='static_boundary_audit.py' or p.suffix.lower() not in {'.html','.js','.py','.json'}: continue
    s=p.read_text(encoding='utf-8',errors='ignore')
    for pat,meaning in PAT:
        if re.search(pat,s): find.append({'file':str(p.relative_to(ROOT)),'meaning':meaning})
res={'package':'DIKWP AI Gaokao ChoiceLab 2026 V3','findings':find,'note':'No credential collection, no official submission adapter, no hidden network calls designed.'}
print(json.dumps(res,ensure_ascii=False,indent=2))
