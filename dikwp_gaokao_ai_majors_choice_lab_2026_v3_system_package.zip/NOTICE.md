# NOTICE

DIKWP AI Gaokao ChoiceLab 2026 V3 is a synthetic-data reference implementation for志愿 planning, open-source demonstration, school counseling, and family discussion. It is not an official admission system and does not guarantee admission.

Attribution: Yucong Duan / DIKWP ecosystem reference implementation.
