# 30-Day Pilot Plan

## Days 1–3
Select one province and one school counseling team. Confirm no credential collection and no official submission.

## Days 4–7
Import the province's 2026 official admission plan and build the AI major taxonomy for that province.

## Days 8–14
Run 10 synthetic student profiles and 5 real volunteer-history cases with anonymized ranks. Verify hard filters and charter checks.

## Days 15–21
Conduct parent/student counseling sessions. Record wrong recommendations, missing data, and charter redlines.

## Days 22–26
Improve templates, province rules, program-group risk, AI future scenarios, and family consensus workflow.

## Days 27–30
Publish the open demo, source ledger, and a no-guarantee counseling protocol.
